import React, { useEffect, useMemo, useState } from "react";
import { Search, Plus, RefreshCw, Eye, CheckCircle2, XCircle, Download } from "lucide-react";
import { getTcLcRequests, approveTcLc, downloadTcLcPdf } from "./tcLcService";
import { getStudentNameMap } from "../students/studentService";
import { getErrorMessage } from "../../services/api";
import { titleCase, inputClass } from "../../services/helpers";
import { fmtDateTime } from "../fees/feeUtils";
import { TYPES, STATUSES, readRequest, statusClass } from "./tcLcUtils";
import CreateTcLc from "./CreateTcLc";
import RejectTcLc from "./RejectTcLc";
import TcLcDetails from "./TcLcDetails";

// TC / LC requests: list, create, approve, reject, download the certificate
const ManageTcLc = () => {
  const [requests, setRequests] = useState([]);
  const [names, setNames] = useState({});
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");
  const [reloadKey, setReloadKey] = useState(0);

  const [query, setQuery] = useState("");
  const [typeFilter, setTypeFilter] = useState("");
  const [statusFilter, setStatusFilter] = useState("");

  const [showCreate, setShowCreate] = useState(false);
  const [rejecting, setRejecting] = useState(null);
  const [viewId, setViewId] = useState(null);
  const [busyId, setBusyId] = useState(null);

  // GET /tc-lc?status=&type=
  useEffect(() => {
    let cancelled = false;
    Promise.all([getTcLcRequests({ status: statusFilter, type: typeFilter }), getStudentNameMap().catch(() => ({}))])
      .then(([list, nameMap]) => {
        if (cancelled) return;
        setRequests(list);
        setNames(nameMap);
        setError("");
      })
      .catch((err) => !cancelled && setError(getErrorMessage(err, "Could not load TC / LC requests")))
      .finally(() => !cancelled && setLoading(false));
    return () => {
      cancelled = true;
    };
  }, [statusFilter, typeFilter, reloadKey]);

  const reload = () => {
    setLoading(true);
    setReloadKey((k) => k + 1);
  };

  const applyFilter = (setter) => (value) => {
    setLoading(true);
    setter(value);
  };

  const rows = useMemo(() => requests.map((r) => readRequest(r, names)), [requests, names]);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return q ? rows.filter((r) => r.name.toLowerCase().includes(q) || r.code.toLowerCase().includes(q)) : rows;
  }, [rows, query]);

  // PUT /tc-lc/:id/approve
  const approve = async (r) => {
    if (!window.confirm(`Approve the ${r.type} request of ${r.name}? The certificate will be issued.`)) return;
    setBusyId(r.id);
    setError("");
    try {
      const res = await approveTcLc(r.id);
      setNotice(res.message || `${r.type} request approved`);
      reload();
    } catch (err) {
      setError(getErrorMessage(err, "Could not approve the request"));
    } finally {
      setBusyId(null);
    }
  };

  // GET /tc-lc/:id/pdf
  const downloadPdf = async (r) => {
    setBusyId(r.id);
    setError("");
    try {
      await downloadTcLcPdf(r.id);
    } catch (err) {
      setError(getErrorMessage(err, "Could not download the certificate"));
    } finally {
      setBusyId(null);
    }
  };

  return (
    <div>
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-6">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">TC / LC Requests</h1>
          <p className="text-sm text-gray-500 mt-1">Transfer and leaving certificates: check eligibility, approve and download</p>
        </div>
        <div className="flex items-center gap-3">
          <button onClick={reload} className="p-2.5 rounded-lg border border-gray-300 text-gray-600 hover:bg-gray-50" aria-label="Refresh">
            <RefreshCw size={18} className={loading ? "animate-spin" : ""} />
          </button>
          <button
            onClick={() => setShowCreate(true)}
            className="flex items-center gap-2 px-4 py-2.5 rounded-lg bg-[#16A34A] text-white font-medium hover:bg-[#15803D]"
          >
            <Plus size={18} /> New request
          </button>
        </div>
      </div>

      <div className="flex flex-col md:flex-row gap-3 mb-4">
        <div className="relative flex-1">
          <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search by student name or ID"
            className={`${inputClass} pl-9 bg-white`}
          />
        </div>
        <select value={typeFilter} onChange={(e) => applyFilter(setTypeFilter)(e.target.value)} className={`${inputClass} md:w-44 bg-white`}>
          <option value="">TC and LC</option>
          {TYPES.map((t) => (
            <option key={t.value} value={t.value}>{t.value}</option>
          ))}
        </select>
        <select value={statusFilter} onChange={(e) => applyFilter(setStatusFilter)(e.target.value)} className={`${inputClass} md:w-44 bg-white`}>
          <option value="">All status</option>
          {STATUSES.map((s) => (
            <option key={s} value={s}>{titleCase(s)}</option>
          ))}
        </select>
      </div>

      {notice && (
        <div className="mb-4 rounded-lg bg-green-50 border border-green-200 text-green-700 text-sm px-4 py-3 flex justify-between">
          <span>{notice}</span>
          <button onClick={() => setNotice("")} aria-label="Dismiss">×</button>
        </div>
      )}
      {error && <div className="mb-4 rounded-lg bg-red-50 border border-red-200 text-red-700 text-sm px-4 py-3">{error}</div>}

      <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-x-auto">
        <table className="w-full text-sm text-left">
          <thead className="bg-gray-50 text-gray-600">
            <tr>
              <th className="px-4 py-3 font-medium">Student</th>
              <th className="px-4 py-3 font-medium">Certificate</th>
              <th className="px-4 py-3 font-medium">Reason</th>
              <th className="px-4 py-3 font-medium">Requested</th>
              <th className="px-4 py-3 font-medium">Status</th>
              <th className="px-4 py-3 font-medium text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-100">
            {loading ? (
              <tr>
                <td colSpan={6} className="px-4 py-10 text-center text-gray-500">Loading requests...</td>
              </tr>
            ) : filtered.length === 0 ? (
              <tr>
                <td colSpan={6} className="px-4 py-10 text-center text-gray-500">
                  {rows.length === 0 ? "No TC / LC requests yet." : "No requests match your search."}
                </td>
              </tr>
            ) : (
              filtered.map((r) => (
                <tr key={r.id} className="hover:bg-gray-50">
                  <td className="px-4 py-3">
                    <p className="font-medium text-gray-900">{r.name}</p>
                    <p className="text-xs text-gray-500 font-mono">{r.code}</p>
                  </td>
                  <td className="px-4 py-3">
                    <span className="px-2.5 py-1 rounded-md bg-gray-100 text-gray-700 text-xs font-semibold">{r.type || "-"}</span>
                  </td>
                  <td className="px-4 py-3 text-gray-600 max-w-xs truncate">{r.reason || "-"}</td>
                  <td className="px-4 py-3 text-gray-600 whitespace-nowrap">{r.date ? fmtDateTime(r.date) : "-"}</td>
                  <td className="px-4 py-3">
                    <span className={`px-2.5 py-1 rounded-full text-xs font-medium ${statusClass(r.status)}`}>{titleCase(r.status)}</span>
                  </td>
                  <td className="px-4 py-3">
                    <div className="flex items-center justify-end gap-1 whitespace-nowrap">
                      <button
                        onClick={() => setViewId(r.id)}
                        title="View and check eligibility"
                        className="p-2 rounded-lg text-gray-500 hover:bg-gray-100 hover:text-gray-800"
                      >
                        <Eye size={16} />
                      </button>
                      {r.status === "pending" && (
                        <>
                          <button
                            onClick={() => approve(r)}
                            disabled={busyId === r.id}
                            title="Approve"
                            className="p-2 rounded-lg text-gray-500 hover:bg-green-50 hover:text-green-700 disabled:opacity-50"
                          >
                            <CheckCircle2 size={16} />
                          </button>
                          <button
                            onClick={() => setRejecting(r)}
                            title="Reject"
                            className="p-2 rounded-lg text-gray-500 hover:bg-red-50 hover:text-red-600"
                          >
                            <XCircle size={16} />
                          </button>
                        </>
                      )}
                      {r.status === "approved" && (
                        <button
                          onClick={() => downloadPdf(r)}
                          disabled={busyId === r.id}
                          title="Download certificate (PDF)"
                          className="p-2 rounded-lg text-gray-500 hover:bg-gray-100 hover:text-gray-800 disabled:opacity-50"
                        >
                          <Download size={16} />
                        </button>
                      )}
                    </div>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {showCreate && (
        <CreateTcLc
          onClose={() => setShowCreate(false)}
          onSaved={(msg) => {
            setShowCreate(false);
            setNotice(msg);
            reload();
          }}
        />
      )}
      {rejecting && (
        <RejectTcLc
          request={rejecting}
          onClose={() => setRejecting(null)}
          onRejected={(msg) => {
            setRejecting(null);
            setNotice(msg);
            reload();
          }}
        />
      )}
      {viewId && <TcLcDetails id={viewId} names={names} onClose={() => setViewId(null)} />}
    </div>
  );
};

export default ManageTcLc;
