import React from "react";
import { KeyValueList } from "../../components/DataViews";
import { flattenRows } from "../fees/feeUtils";
import { readEligibility } from "./tcLcUtils";

// Shows an eligibility result: green / red banner, the message and any extra details
const EligibilityPanel = ({ loading, result, error }) => {
  if (loading) return <p className="text-sm text-gray-500">Checking eligibility...</p>;
  if (error) return <p className="text-sm text-red-600">{error}</p>;
  if (!result) return null;

  const { eligible, message, extra } = readEligibility(result);
  return (
    <div className="space-y-3">
      {eligible !== undefined && (
        <div
          className={`rounded-lg border px-4 py-3 text-sm font-medium ${
            eligible ? "border-green-200 bg-green-50 text-green-800" : "border-red-200 bg-red-50 text-red-800"
          }`}
        >
          {eligible ? "Eligible" : "Not eligible"}
          {message ? <span className="block mt-0.5 font-normal">{message}</span> : null}
        </div>
      )}
      {eligible === undefined && message && <p className="text-sm text-gray-700">{message}</p>}
      {flattenRows(extra).length > 0 && <KeyValueList data={extra} />}
    </div>
  );
};

export default EligibilityPanel;
