import { pick, relId } from "../schedules/scheduleUtils";

export const TYPES = [
  { value: "TC", label: "Transfer Certificate (TC)" },
  { value: "LC", label: "Leaving Certificate (LC)" },
];

// Statuses offered in the filter. The API doc does not list them - edit if your backend uses others.
export const STATUSES = ["pending", "approved", "rejected"];

export const STATUS_STYLES = {
  pending: "bg-amber-100 text-amber-700",
  approved: "bg-green-100 text-green-700",
  rejected: "bg-red-100 text-red-700",
};
export const statusClass = (s) => STATUS_STYLES[s] || "bg-gray-100 text-gray-600";

// One request from the API -> plain fields (student can come back as an id or a populated object)
export const readRequest = (r, names = {}) => {
  const ref = pick(r, "studentId", "student_id", "student");
  const id = relId(ref);
  const obj = ref && typeof ref === "object" ? ref : {};
  return {
    id: r._id || r.id,
    studentId: id,
    name: obj.full_name || obj.name || r.student_name || names[id] || "Unknown student",
    code: obj.student_id || "",
    type: String(r.type || "").toUpperCase(),
    status: String(r.status || "pending").toLowerCase(),
    reason: r.reason || "",
    rejectReason: r.reject_reason || r.rejection_reason || r.rejected_reason || "",
    date: r.createdAt || r.requested_at,
  };
};

const FLAG_KEYS = ["eligible", "isEligible", "is_eligible"];
const MESSAGE_KEYS = ["message", "reason", "remarks"];

// Eligibility response -> { eligible, message, extra }
export const readEligibility = (result) => {
  const data = result?.data && typeof result.data === "object" ? result.data : {};
  const flagKey = FLAG_KEYS.find((k) => typeof data[k] === "boolean");
  const messageKey = MESSAGE_KEYS.find((k) => typeof data[k] === "string" && data[k]);
  const shown = [flagKey, messageKey].filter(Boolean);
  return {
    eligible: flagKey ? data[flagKey] : undefined,
    message: (messageKey && data[messageKey]) || result?.message || "",
    extra: Object.fromEntries(Object.entries(data).filter(([k]) => !shown.includes(k))),
  };
};
