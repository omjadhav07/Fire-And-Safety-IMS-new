import React, { useEffect, useState } from "react";
import { ShieldCheck } from "lucide-react";
import { getTcLcById, checkRequestEligibility } from "./tcLcService";
import { getErrorMessage } from "../../services/api";
import Modal from "../../components/Modal";
import { fmtDateTime } from "../fees/feeUtils";
import { titleCase } from "../../services/helpers";
import { readRequest, statusClass } from "./tcLcUtils";
import EligibilityPanel from "./EligibilityPanel";

// GET /tc-lc/:id  (+ GET /tc-lc/:id/eligibility on demand)
const TcLcDetails = ({ id, names, onClose }) => {
  const [data, setData] = useState(null);
  const [error, setError] = useState("");
  const [elig, setElig] = useState(null); // { loading, result, error }

  useEffect(() => {
    let cancelled = false;
    getTcLcById(id)
      .then((d) => !cancelled && setData(d))
      .catch((err) => !cancelled && setError(getErrorMessage(err, "Could not load the request")));
    return () => {
      cancelled = true;
    };
  }, [id]);

  const check = async () => {
    setElig({ loading: true, result: null, error: "" });
    try {
      setElig({ loading: false, result: await checkRequestEligibility(id), error: "" });
    } catch (err) {
      setElig({ loading: false, result: null, error: getErrorMessage(err, "Could not check eligibility") });
    }
  };

  const r = data ? readRequest(data, names) : null;
  const rows = r && [
    ["Student", r.name],
    ["Student ID", r.code],
    ["Certificate", r.type],
    ["Reason", r.reason],
    ["Rejection reason", r.rejectReason],
    ["Requested on", r.date ? fmtDateTime(r.date) : ""],
  ].filter(([, v]) => v);

  return (
    <Modal title="TC / LC request" onClose={onClose} maxWidth="max-w-lg">
      {error && <p className="text-sm text-red-600">{error}</p>}
      {!data && !error && <p className="text-sm text-gray-500">Loading...</p>}
      {r && (
        <div className="space-y-4">
          <div className="flex items-center justify-between gap-3">
            <h3 className="text-lg font-semibold text-gray-900">{r.type} · {r.name}</h3>
            <span className={`px-2.5 py-1 rounded-full text-xs font-medium ${statusClass(r.status)}`}>{titleCase(r.status)}</span>
          </div>
          <dl className="divide-y divide-gray-100 text-sm border-t border-gray-100">
            {rows.map(([label, value]) => (
              <div key={label} className="flex justify-between gap-4 py-2.5">
                <dt className="text-gray-500 shrink-0">{label}</dt>
                <dd className="font-medium text-gray-900 text-right break-words">{value}</dd>
              </div>
            ))}
          </dl>

          <div>
            <button
              onClick={check}
              disabled={elig?.loading}
              className="inline-flex items-center gap-2 px-4 py-2.5 rounded-lg border border-gray-300 text-gray-700 hover:bg-gray-50 disabled:opacity-60"
            >
              <ShieldCheck size={16} /> Check eligibility
            </button>
            {elig && (
              <div className="mt-3">
                <EligibilityPanel loading={elig.loading} result={elig.result} error={elig.error} />
              </div>
            )}
          </div>
        </div>
      )}
    </Modal>
  );
};

export default TcLcDetails;
