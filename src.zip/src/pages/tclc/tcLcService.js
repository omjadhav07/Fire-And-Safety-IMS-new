import api from "../../services/api";
import { saveBlob, unwrapBlobError } from "../library/bookImportExportService";

const unwrap = (data) => data?.data ?? data;
const BASE = "/tc-lc";

const listOf = (payload, keys = []) => {
  if (Array.isArray(payload)) return payload;
  for (const k of [...keys, "items", "rows"]) if (Array.isArray(payload?.[k])) return payload[k];
  return [];
};

// GET /tc-lc/students/:studentId/eligibility  - can this student be given a TC / LC?
export const checkStudentEligibility = async (studentId) => {
  const { data } = await api.get(`${BASE}/students/${studentId}/eligibility`);
  return { message: data?.message, data: unwrap(data) };
};

// POST /tc-lc  { studentId, type: "TC" | "LC", reason }
export const createTcLcRequest = async (body) => {
  const { data } = await api.post(BASE, body);
  return { message: data?.message, request: unwrap(data) };
};

// GET /tc-lc?status=&type=
export const getTcLcRequests = async ({ status, type } = {}) => {
  const params = {};
  if (status) params.status = status;
  if (type) params.type = type;
  const { data } = await api.get(BASE, { params });
  return listOf(unwrap(data), ["requests", "tcLc", "tc_lc"]);
};

// GET /tc-lc/:id
export const getTcLcById = async (id) => {
  const { data } = await api.get(`${BASE}/${id}`);
  const payload = unwrap(data);
  return payload?.request ?? payload;
};

// GET /tc-lc/:id/eligibility  - eligibility of an existing request
export const checkRequestEligibility = async (id) => {
  const { data } = await api.get(`${BASE}/${id}/eligibility`);
  return { message: data?.message, data: unwrap(data) };
};

// PUT /tc-lc/:id/approve
export const approveTcLc = async (id) => {
  const { data } = await api.put(`${BASE}/${id}/approve`);
  return { message: data?.message };
};

// PUT /tc-lc/:id/reject  { reason }
export const rejectTcLc = async (id, reason) => {
  const { data } = await api.put(`${BASE}/${id}/reject`, { reason });
  return { message: data?.message };
};

// GET /tc-lc/:id/pdf  - downloads the certificate
export const downloadTcLcPdf = async (id) => {
  try {
    const res = await api.get(`${BASE}/${id}/pdf`, { responseType: "blob", timeout: 120000 });
    saveBlob(res, `tc-lc-${id}.pdf`);
  } catch (err) {
    throw await unwrapBlobError(err);
  }
};

// GET /tc-lc/my-requests  (student)
export const getMyTcLcRequests = async () => {
  const { data } = await api.get(`${BASE}/my-requests`);
  return listOf(unwrap(data), ["requests", "tcLc", "tc_lc"]);
};
