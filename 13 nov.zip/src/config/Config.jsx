const BASE_URL = "http://192.168.1.6:4000/api/v1";

export default BASE_URL;