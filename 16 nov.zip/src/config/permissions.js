// export const ROLE = {
//   SUPER_ADMIN: "super_admin",
//   OFFICE_STAFF: "office_staff",
//   FACULTY: "faculty",
//   LIBRARIAN: "librarian",
//   STUDENT: "student",
// };

// const { SUPER_ADMIN, OFFICE_STAFF, FACULTY, LIBRARIAN, STUDENT } = ROLE;

// // page key -> roles allowed ("all" = every logged-in user). Based on the Permission Matrix (15.2).
// export const ACCESS = {
//   dashboard: "all",
//   notices: "all",
//   files: "all",

//   users: [SUPER_ADMIN], //                                   Users & Roles
//   courses: [SUPER_ADMIN, OFFICE_STAFF, FACULTY], //           Course Master (faculty: view)
//   facultyAssignments: [SUPER_ADMIN, OFFICE_STAFF, FACULTY], // Course Master
//   classSchedules: [SUPER_ADMIN, OFFICE_STAFF, FACULTY], //    Class Schedule
//   studyMaterial: [SUPER_ADMIN, OFFICE_STAFF, FACULTY], //     Study Material (office staff: view only)
//   classTests: [SUPER_ADMIN, OFFICE_STAFF, FACULTY], //        Tests / Exams / Marks
//   examResults: [SUPER_ADMIN, OFFICE_STAFF, FACULTY], //       Result Publish / Exams
//   examForms: [SUPER_ADMIN, OFFICE_STAFF, FACULTY], //         Exam Forms (staff view; students use the app)
//   enquiries: [SUPER_ADMIN, OFFICE_STAFF], //                  Enquiry / Admission
//   students: [SUPER_ADMIN, OFFICE_STAFF], //                   Admission / Documents / TC-LC
//   fees: [SUPER_ADMIN, OFFICE_STAFF], //                       Fees / Receipts
//   myFees: [], //                                              Students use the student app, not the website
//   library: [SUPER_ADMIN, OFFICE_STAFF, LIBRARIAN], //         Library (office staff: view)
//   auditLogs: [SUPER_ADMIN], //                                Audit Log
// };

// // Role of the logged-in user (saved at login, refreshed by the header)
// export const getCurrentUser = () => {
//   try {
//     return JSON.parse(localStorage.getItem("userData") || "null");
//   } catch {
//     return null;
//   }
// };

// export const getCurrentRole = () => {
//   const u = getCurrentUser();
//   return typeof u?.role === "string" ? u.role : u?.role?.name || u?.roles?.[0]?.name || "";
// };

// // Unknown page keys are open; unknown roles only get the "all" pages
// export const canAccess = (role, key) => {
//   const allowed = ACCESS[key];
//   if (!allowed) return true;
//   if (allowed === "all") return true;
//   return allowed.includes(role);
// };

// export const roleLabel = (role) =>
//   String(role || "")
//     .replace(/_/g, " ")
//     .replace(/\b\w/g, (c) => c.toUpperCase()) || "User";



// // Who can open what. One place to change when the permission matrix changes.
// // The sidebar, the route guard and the dashboards all read from here.
// // (This only controls what the screen shows. The API must still enforce the same rules.)

// export const ROLE = {
//   SUPER_ADMIN: "super_admin",
//   OFFICE_STAFF: "office_staff",
//   FACULTY: "faculty",
//   LIBRARIAN: "librarian",
//   STUDENT: "student",
// };

// const { SUPER_ADMIN, OFFICE_STAFF, FACULTY, LIBRARIAN, STUDENT } = ROLE;

// // page key -> roles allowed ("all" = every logged-in user). Based on the Permission Matrix (15.2).
// export const ACCESS = {
//   dashboard: "all",
//   notices: "all",
//   files: "all",

//   users: [SUPER_ADMIN], //                                   Users & Roles
//   courses: [SUPER_ADMIN, OFFICE_STAFF, FACULTY, STUDENT], //  Course Master (faculty / student: view)
//   facultyAssignments: [SUPER_ADMIN, OFFICE_STAFF, FACULTY], // Course Master
//   classSchedules: [SUPER_ADMIN, OFFICE_STAFF, FACULTY, STUDENT], // Class Schedule
//   classTests: [SUPER_ADMIN, OFFICE_STAFF, FACULTY], //        Tests / Exams / Marks
//   examResults: [SUPER_ADMIN, OFFICE_STAFF, FACULTY], //       Result Publish / Exams
//   enquiries: [SUPER_ADMIN, OFFICE_STAFF], //                  Enquiry / Admission
//   students: [SUPER_ADMIN, OFFICE_STAFF], //                   Admission / Documents / TC-LC
//   fees: [SUPER_ADMIN, OFFICE_STAFF], //                       Fees / Receipts
//   myFees: [STUDENT], //                                       Fees / Receipts: view own
//   library: [SUPER_ADMIN, OFFICE_STAFF, LIBRARIAN], //         Library (office staff: view)
//   auditLogs: [SUPER_ADMIN], //                                Audit Log
// };

// // Role of the logged-in user (saved at login, refreshed by the header)
// export const getCurrentUser = () => {
//   try {
//     return JSON.parse(localStorage.getItem("userData") || "null");
//   } catch {
//     return null;
//   }
// };

// export const getCurrentRole = () => {
//   const u = getCurrentUser();
//   return typeof u?.role === "string" ? u.role : u?.role?.name || u?.roles?.[0]?.name || "";
// };

// // Unknown page keys are open; unknown roles only get the "all" pages
// export const canAccess = (role, key) => {
//   const allowed = ACCESS[key];
//   if (!allowed) return true;
//   if (allowed === "all") return true;
//   return allowed.includes(role);
// };

// export const roleLabel = (role) =>
//   String(role || "")
//     .replace(/_/g, " ")
//     .replace(/\b\w/g, (c) => c.toUpperCase()) || "User";



// Who can open what. One place to change when the permission matrix changes.
// The sidebar, the route guard and the dashboards all read from here.
// (This only controls what the screen shows. The API must still enforce the same rules.)

// export const ROLE = {
//   SUPER_ADMIN: "super_admin",
//   OFFICE_STAFF: "office_staff",
//   FACULTY: "faculty",
//   LIBRARIAN: "librarian",
//   STUDENT: "student",
// };

// const { SUPER_ADMIN, OFFICE_STAFF, FACULTY, LIBRARIAN, STUDENT } = ROLE;

// // page key -> roles allowed ("all" = every logged-in user). Based on the Permission Matrix (15.2).
// export const ACCESS = {
//   dashboard: "all",
//   notices: "all",
//   files: "all",

//   users: [SUPER_ADMIN], //                                   Users & Roles
//   courses: [SUPER_ADMIN, OFFICE_STAFF, FACULTY, STUDENT], //  Course Master (faculty / student: view)
//   facultyAssignments: [SUPER_ADMIN, OFFICE_STAFF, FACULTY], // Course Master
//   classSchedules: [SUPER_ADMIN, OFFICE_STAFF, FACULTY, STUDENT], // Class Schedule
//   studyMaterial: [SUPER_ADMIN, OFFICE_STAFF, FACULTY, STUDENT], // Study Material (office staff / student: view only)
//   classTests: [SUPER_ADMIN, OFFICE_STAFF, FACULTY], //        Tests / Exams / Marks
//   examResults: [SUPER_ADMIN, OFFICE_STAFF, FACULTY], //       Result Publish / Exams
//   enquiries: [SUPER_ADMIN, OFFICE_STAFF], //                  Enquiry / Admission
//   students: [SUPER_ADMIN, OFFICE_STAFF], //                   Admission / Documents / TC-LC
//   fees: [SUPER_ADMIN, OFFICE_STAFF], //                       Fees / Receipts
//   myFees: [STUDENT], //                                       Fees / Receipts: view own
//   library: [SUPER_ADMIN, OFFICE_STAFF, LIBRARIAN], //         Library (office staff: view)
//   auditLogs: [SUPER_ADMIN], //                                Audit Log
// };

// // Role of the logged-in user (saved at login, refreshed by the header)
// export const getCurrentUser = () => {
//   try {
//     return JSON.parse(localStorage.getItem("userData") || "null");
//   } catch {
//     return null;
//   }
// };

// export const getCurrentRole = () => {
//   const u = getCurrentUser();
//   return typeof u?.role === "string" ? u.role : u?.role?.name || u?.roles?.[0]?.name || "";
// };

// // Unknown page keys are open; unknown roles only get the "all" pages
// export const canAccess = (role, key) => {
//   const allowed = ACCESS[key];
//   if (!allowed) return true;
//   if (allowed === "all") return true;
//   return allowed.includes(role);
// };

// export const roleLabel = (role) =>
//   String(role || "")
//     .replace(/_/g, " ")
//     .replace(/\b\w/g, (c) => c.toUpperCase()) || "User";
    

// Who can open what. One place to change when the permission matrix changes.
// The sidebar, the route guard and the dashboards all read from here.
// (This only controls what the screen shows. The API must still enforce the same rules.)
// import { useEffect, useState } from "react";

// export const ROLE = {
//   SUPER_ADMIN: "super_admin",
//   OFFICE_STAFF: "office_staff",
//   FACULTY: "faculty",
//   LIBRARIAN: "librarian",
//   STUDENT: "student",
// };

// const { SUPER_ADMIN, OFFICE_STAFF, FACULTY, LIBRARIAN, STUDENT } = ROLE;

// // page key -> roles allowed ("all" = every logged-in user). Based on the Permission Matrix (15.2).
// // Used as the fallback while the user's own permissions are not known (see PAGE_PERMISSIONS below).
// export const ACCESS = {
//   dashboard: "all",
//   notices: "all",
//   files: "all",

//   users: [SUPER_ADMIN], //                                   Users & Roles
//   courses: [SUPER_ADMIN, OFFICE_STAFF, FACULTY], //           Course Master (faculty: view)
//   facultyAssignments: [SUPER_ADMIN, OFFICE_STAFF, FACULTY], // Course Master
//   classSchedules: [SUPER_ADMIN, OFFICE_STAFF, FACULTY], //    Class Schedule
//   studyMaterial: [SUPER_ADMIN, OFFICE_STAFF, FACULTY], //     Study Material (office staff: view only)
//   classTests: [SUPER_ADMIN, OFFICE_STAFF, FACULTY], //        Tests / Exams / Marks
//   examResults: [SUPER_ADMIN, OFFICE_STAFF, FACULTY], //       Result Publish / Exams
//   examForms: [SUPER_ADMIN, OFFICE_STAFF, FACULTY], //         Exam Forms (staff view; students use the app)
//   enquiries: [SUPER_ADMIN, OFFICE_STAFF], //                  Enquiry / Admission
//   students: [SUPER_ADMIN, OFFICE_STAFF], //                   Admission / Documents / TC-LC
//   fees: [SUPER_ADMIN, OFFICE_STAFF], //                       Fees / Receipts
//   myFees: [], //                                              Students use the student app, not the website
//   library: [SUPER_ADMIN, OFFICE_STAFF, LIBRARIAN], //         Library (office staff: view)
//   tcLc: [SUPER_ADMIN, OFFICE_STAFF], //                       TC / LC
//   auditLogs: [SUPER_ADMIN], //                                Audit Log
// };

// // page key -> permission codes (from Roles & Permissions). The page opens when the user's role has ANY of them.
// // Edit a role's permissions in Roles & Permissions and the sidebar / pages follow it. Super Admin always sees everything.
// // dashboard, notices and files are open to every logged-in user.
// export const PAGE_PERMISSIONS = {
//   users: ["users.manage"],
//   courses: ["courses.manage"],
//   facultyAssignments: ["courses.manage"],
//   classSchedules: ["courses.manage"],
//   studyMaterial: ["courses.manage", "exams.manage"], //  no study-material permission exists yet
//   classTests: ["exams.manage"],
//   examResults: ["exams.manage"],
//   examForms: ["exams.manage", "exam_forms.override"],
//   enquiries: ["students.manage"],
//   students: ["students.manage", "students.view"],
//   fees: ["fees.manage", "fees.view"],
//   library: ["library.manage"],
//   tcLc: ["tc_lc.manage"],
//   auditLogs: ["users.manage"], //                        no audit-log permission exists yet
// };

// // Role of the logged-in user (saved at login, refreshed by the header)
// export const getCurrentUser = () => {
//   try {
//     return JSON.parse(localStorage.getItem("userData") || "null");
//   } catch {
//     return null;
//   }
// };

// export const getCurrentRole = () => {
//   const u = getCurrentUser();
//   return typeof u?.role === "string" ? u.role : u?.role?.name || u?.roles?.[0]?.name || "";
// };

// // Permission codes of a user, read from user.permissions, user.role.permissions or user.roles[].permissions
// // (codes or { _id, code } objects). Returns null when the API did not send them.
// const toCodes = (list) => {
//   if (!Array.isArray(list)) return null;
//   const codes = list.map((p) => (typeof p === "string" ? p : p?.code)).filter(Boolean);
//   return codes.length && !codes.some((c) => c.includes(".")) ? null : codes; // ids only -> unknown
// };

// export const getPermissionCodes = (user = getCurrentUser()) => {
//   if (!user) return null;
//   const direct = toCodes(user.permissions) ?? toCodes(user.role?.permissions);
//   if (direct) return direct;
//   if (Array.isArray(user.roles)) {
//     const lists = user.roles.map((r) => toCodes(r?.permissions)).filter(Boolean);
//     if (lists.length) return [...new Set(lists.flat())];
//   }
//   return null;
// };

// // Unknown page keys are open. Super Admin follows the fixed list above (always full access).
// // Everyone else follows their permission codes; if the API did not send any, the role list is used.
// export const canAccess = (role, key) => {
//   const allowed = ACCESS[key];
//   if (!allowed) return true;
//   if (allowed === "all") return true;
//   if (role === SUPER_ADMIN) return allowed.includes(SUPER_ADMIN);
//   const codes = getPermissionCodes();
//   const needed = PAGE_PERMISSIONS[key];
//   if (codes && needed) return needed.some((c) => codes.includes(c));
//   return allowed.includes(role);
// };

// // Re-render a component when the saved user changes (the header refreshes it from /auth/me)
// const USER_EVENT = "ims:user-updated";
// export const notifyUserChanged = () => window.dispatchEvent(new Event(USER_EVENT));
// export const useUserRefresh = () => {
//   const [, setTick] = useState(0);
//   useEffect(() => {
//     const onChange = () => setTick((n) => n + 1);
//     window.addEventListener(USER_EVENT, onChange);
//     return () => window.removeEventListener(USER_EVENT, onChange);
//   }, []);
// };

// export const roleLabel = (role) =>
//   String(role || "")
//     .replace(/_/g, " ")
//     .replace(/\b\w/g, (c) => c.toUpperCase()) || "User";


// 14 nov

import { useEffect, useState } from "react";

export const ROLE = {
  SUPER_ADMIN: "super_admin",
  OFFICE_STAFF: "office_staff",
  FACULTY: "faculty",
  LIBRARIAN: "librarian",
  STUDENT: "student",
};

const { SUPER_ADMIN, OFFICE_STAFF, FACULTY, LIBRARIAN, STUDENT } = ROLE;

// page key -> roles allowed ("all" = every logged-in user). Based on the Permission Matrix (15.2).
// Used as the fallback while the user's own permissions are not known (see PAGE_PERMISSIONS below).
export const ACCESS = {
  dashboard: "all",
  notices: "all",
  files: "all",

  users: [SUPER_ADMIN], //                                   Users & Roles
  courses: [SUPER_ADMIN, OFFICE_STAFF, FACULTY], //           Course Master (faculty: view)
  subjects: [SUPER_ADMIN, OFFICE_STAFF, FACULTY], //          Course Master > Subjects
  facultyAssignments: [SUPER_ADMIN, OFFICE_STAFF, FACULTY], // Course Master
  classSchedules: [SUPER_ADMIN, OFFICE_STAFF, FACULTY], //    Class Schedule
  studyMaterial: [SUPER_ADMIN, OFFICE_STAFF, FACULTY], //     Study Material (office staff: view only)
  classTests: [SUPER_ADMIN, OFFICE_STAFF, FACULTY], //        Tests / Exams / Marks
  examResults: [SUPER_ADMIN, OFFICE_STAFF, FACULTY], //       Result Publish / Exams
  examForms: [SUPER_ADMIN, OFFICE_STAFF, FACULTY], //         Exam Forms (staff view; students use the app)
  enquiries: [SUPER_ADMIN, OFFICE_STAFF], //                  Enquiry / Admission
  students: [SUPER_ADMIN, OFFICE_STAFF], //                   Admission / Documents / TC-LC
  fees: [SUPER_ADMIN, OFFICE_STAFF], //                       Fees / Receipts
  myFees: [], //                                              Students use the student app, not the website
  library: [SUPER_ADMIN, OFFICE_STAFF, LIBRARIAN], //         Library (office staff: view)
  tcLc: [SUPER_ADMIN, OFFICE_STAFF], //                       TC / LC
  auditLogs: [SUPER_ADMIN], //                                Audit Log
};

// page key -> permission codes (from Roles & Permissions). The page opens when the user's role has ANY of them.
// Edit a role's permissions in Roles & Permissions and the sidebar / pages follow it. Super Admin always sees everything.
// dashboard, notices and files are open to every logged-in user.
export const PAGE_PERMISSIONS = {
  users: ["users.manage"],
  courses: ["courses.manage"],
  subjects: ["courses.manage"],
  facultyAssignments: ["courses.manage"],
  classSchedules: ["courses.manage"],
  studyMaterial: ["courses.manage", "exams.manage"], //  no study-material permission exists yet
  classTests: ["exams.manage"],
  examResults: ["exams.manage"],
  examForms: ["exams.manage", "exam_forms.override"],
  enquiries: ["students.manage"],
  students: ["students.manage", "students.view"],
  fees: ["fees.manage", "fees.view"],
  library: ["library.manage"],
  tcLc: ["tc_lc.manage"],
  auditLogs: ["users.manage"], //                        no audit-log permission exists yet
};

// Role of the logged-in user (saved at login, refreshed by the header)
export const getCurrentUser = () => {
  try {
    return JSON.parse(localStorage.getItem("userData") || "null");
  } catch {
    return null;
  }
};

export const getCurrentRole = () => {
  const u = getCurrentUser();
  return typeof u?.role === "string" ? u.role : u?.role?.name || u?.roles?.[0]?.name || "";
};

// Permission codes of a user, read from user.permissions, user.role.permissions or user.roles[].permissions
// (codes or { _id, code } objects). Returns null when the API did not send them.
const toCodes = (list) => {
  if (!Array.isArray(list)) return null;
  const codes = list.map((p) => (typeof p === "string" ? p : p?.code)).filter(Boolean);
  return codes.length && !codes.some((c) => c.includes(".")) ? null : codes; // ids only -> unknown
};

export const getPermissionCodes = (user = getCurrentUser()) => {
  if (!user) return null;
  const direct = toCodes(user.permissions) ?? toCodes(user.role?.permissions);
  if (direct) return direct;
  if (Array.isArray(user.roles)) {
    const lists = user.roles.map((r) => toCodes(r?.permissions)).filter(Boolean);
    if (lists.length) return [...new Set(lists.flat())];
  }
  return null;
};

// Unknown page keys are open. Super Admin follows the fixed list above (always full access).
// Everyone else follows their permission codes; if the API did not send any, the role list is used.
export const canAccess = (role, key) => {
  const allowed = ACCESS[key];
  if (!allowed) return true;
  if (allowed === "all") return true;
  if (role === SUPER_ADMIN) return allowed.includes(SUPER_ADMIN);
  const codes = getPermissionCodes();
  const needed = PAGE_PERMISSIONS[key];
  if (codes && needed) return needed.some((c) => codes.includes(c));
  return allowed.includes(role);
};

// Re-render a component when the saved user changes (the header refreshes it from /auth/me)
const USER_EVENT = "ims:user-updated";
export const notifyUserChanged = () => window.dispatchEvent(new Event(USER_EVENT));
export const useUserRefresh = () => {
  const [, setTick] = useState(0);
  useEffect(() => {
    const onChange = () => setTick((n) => n + 1);
    window.addEventListener(USER_EVENT, onChange);
    return () => window.removeEventListener(USER_EVENT, onChange);
  }, []);
};

export const roleLabel = (role) =>
  String(role || "")
    .replace(/_/g, " ")
    .replace(/\b\w/g, (c) => c.toUpperCase()) || "User";
