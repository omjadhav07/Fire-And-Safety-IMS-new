import React, { useEffect, useMemo, useState } from "react";
import { RefreshCw, Eye, FilePlus2 } from "lucide-react";
import { getExamForms, getExamFormById, submitExamForm } from "./examFormService";
import { getExams } from "../exams/examService";
import { getErrorMessage } from "../../services/api";
import Modal from "../../components/Modal";
import Field from "../../components/Field";
import { fmtDate, titleCase, inputClass } from "../../services/helpers";
import { pick, relId, relName } from "../schedules/scheduleUtils";
import { ROLE, getCurrentRole } from "../../config/permissions";
import { PageHeader, Toolbar, AddButton, TableCard, Notice, Avatar, StatusPill, RowMenu, btnOutline, btnPrimary } from "../../components/ui";

const getId = (o) => (o && typeof o === "object" ? o.id || o._id : o) || "";
const examOf = (f) => pick(f, "exam_id", "exam");
const studentOf = (f) => pick(f, "student_id", "student", "user_id", "user");
const examTitle = (f, map) => relName(examOf(f), map) || f.exam_title || "-";
const examSubject = (f, map) => {
  const e = examOf(f);
  return (e && typeof e === "object" ? e.subject : map?.[relId(e)]?.subject) || "";
};
const studentName = (f) => {
  const s = studentOf(f);
  return (s && typeof s === "object" ? s.name || s.full_name : "") || f.student_name || "-";
};
const statusOf = (f) => String(f.status || "submitted").toLowerCase();
const statusTone = (s) => (["approved", "accepted", "verified", "paid"].includes(s) ? "green" : ["rejected", "cancelled"].includes(s) ? "red" : s === "pending" ? "amber" : "blue");
const submittedAt = (f) => f.submitted_at || f.created_at || f.createdAt;

// An exam accepts forms between its form start and end date (when both are set)
const formsOpen = (e) => {
  const today = new Date().toISOString().slice(0, 10);
  const start = String(e.form_start_date || "").slice(0, 10);
  const end = String(e.form_end_date || "").slice(0, 10);
  if (start && today < start) return false;
  if (end && today > end) return false;
  return !["cancelled", "completed"].includes(String(e.status || "").toLowerCase());
};

const ManageExamForms = () => {
  const isStudent = getCurrentRole() === ROLE.STUDENT;

  const [forms, setForms] = useState([]);
  const [exams, setExams] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");
  const [reloadKey, setReloadKey] = useState(0);
  const [filters, setFilters] = useState({ exam: "", status: "", q: "" });

  const [detail, setDetail] = useState(null); // form being viewed
  const [detailLoading, setDetailLoading] = useState(false);
  const [applying, setApplying] = useState(false);
  const [applyExam, setApplyExam] = useState("");
  const [applyError, setApplyError] = useState("");
  const [saving, setSaving] = useState(false);

  // GET /exam-forms (staff) or /student/exam-forms (student), plus the exams for names and the apply list
  useEffect(() => {
    let cancelled = false;
    Promise.all([getExamForms({ student: isStudent }), getExams({ limit: 100 }).catch(() => [])])
      .then(([list, examList]) => {
        if (cancelled) return;
        setForms(list);
        setExams(examList.list || examList);
        setError("");
      })
      .catch((err) => !cancelled && setError(getErrorMessage(err, "Could not load exam forms")))
      .finally(() => !cancelled && setLoading(false));
    return () => {
      cancelled = true;
    };
  }, [reloadKey, isStudent]);

  const reload = () => {
    setLoading(true);
    setReloadKey((k) => k + 1);
  };

  const examMap = useMemo(() => Object.fromEntries(exams.map((e) => [getId(e), e])), [exams]);
  const examNames = useMemo(() => Object.fromEntries(exams.map((e) => [getId(e), e.title || e.name])), [exams]);

  const statuses = useMemo(() => [...new Set(forms.map(statusOf))].sort(), [forms]);

  const shown = useMemo(() => {
    const q = filters.q.trim().toLowerCase();
    return forms.filter((f) => {
      if (filters.exam && relId(examOf(f)) !== filters.exam) return false;
      if (filters.status && statusOf(f) !== filters.status) return false;
      if (!q) return true;
      return [studentName(f), examTitle(f, examNames), examSubject(f, examMap), f.roll_no, f.form_no].some((v) =>
        String(v ?? "").toLowerCase().includes(q)
      );
    });
  }, [forms, filters, examNames, examMap]);

  // Exams the student can still apply for
  const appliedIds = useMemo(() => new Set(forms.map((f) => relId(examOf(f)))), [forms]);
  const applyable = useMemo(() => exams.filter((e) => formsOpen(e) && !appliedIds.has(getId(e))), [exams, appliedIds]);

  const openDetail = async (f) => {
    setDetail(f);
    if (isStudent) return; // students have no single-form endpoint; the row already has the details
    setDetailLoading(true);
    try {
      setDetail(await getExamFormById(getId(f)));
    } catch (err) {
      setError(getErrorMessage(err, "Could not load the exam form"));
    } finally {
      setDetailLoading(false);
    }
  };

  // POST /student/exam-forms  { exam_id }
  const handleApply = async (e) => {
    e.preventDefault();
    if (!applyExam) return setApplyError("Select an exam");
    setSaving(true);
    setApplyError("");
    try {
      await submitExamForm(applyExam);
      setApplying(false);
      setApplyExam("");
      setNotice("Exam form submitted");
      reload();
    } catch (err) {
      setApplyError(getErrorMessage(err, "Could not submit the exam form"));
    } finally {
      setSaving(false);
    }
  };

  const colSpan = isStudent ? 6 : 7;
  const hasFilter = !!(filters.exam || filters.status || filters.q);

  return (
    <div>
      <PageHeader
        title="Exam Forms"
        subtitle={isStudent ? "Apply for exams and track your forms" : "Exam forms submitted by students"}
      />

      {notice && <Notice onClose={() => setNotice("")}>{notice}</Notice>}
      {error && <Notice tone="error">{error}</Notice>}

      <Toolbar value={filters.q} onChange={(v) => setFilters((f) => ({ ...f, q: v }))} placeholder={isStudent ? "Search exam or subject" : "Search student, exam or subject"}>
        <select
          value={filters.exam}
          onChange={(e) => setFilters((f) => ({ ...f, exam: e.target.value }))}
          className="px-3 py-2 text-sm rounded-lg border border-slate-200 bg-white max-w-[14rem]"
        >
          <option value="">All exams</option>
          {exams.map((e) => (
            <option key={getId(e)} value={getId(e)}>{e.title || e.name}</option>
          ))}
        </select>
        <select
          value={filters.status}
          onChange={(e) => setFilters((f) => ({ ...f, status: e.target.value }))}
          className="px-3 py-2 text-sm rounded-lg border border-slate-200 bg-white"
        >
          <option value="">All status</option>
          {statuses.map((s) => (
            <option key={s} value={s}>{titleCase(s)}</option>
          ))}
        </select>
        <button onClick={reload} className={btnOutline} aria-label="Refresh">
          <RefreshCw size={15} className={loading ? "animate-spin" : ""} />
        </button>
        {isStudent && <AddButton onClick={() => setApplying(true)}>Apply for exam</AddButton>}
      </Toolbar>

      <TableCard>
        <table className="w-full text-sm text-left">
          <thead className="bg-[#0B1437] text-white">
            <tr>
              {!isStudent && <th className="px-4 py-3">Student</th>}
              <th className="px-4 py-3">Exam</th>
              <th className="px-4 py-3">Subject</th>
              <th className="px-4 py-3">Exam date</th>
              <th className="px-4 py-3">Submitted</th>
              <th className="px-4 py-3">Status</th>
              <th className="px-4 py-3 text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {loading ? (
              <tr><td colSpan={colSpan + 1} className="px-4 py-10 text-center text-slate-500">Loading exam forms...</td></tr>
            ) : shown.length === 0 ? (
              <tr>
                <td colSpan={colSpan + 1} className="px-4 py-10 text-center text-slate-500">
                  {hasFilter ? "No exam forms match your filters." : isStudent ? "You have not submitted any exam form yet." : "No exam forms yet."}
                </td>
              </tr>
            ) : (
              shown.map((f, i) => {
                const examObj = examOf(f);
                const examDate = (examObj && typeof examObj === "object" ? examObj.exam_date : examMap[relId(examObj)]?.exam_date) || f.exam_date;
                return (
                  <tr key={getId(f) || i}>
                    {!isStudent && (
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-3">
                          <Avatar name={studentName(f)} />
                          <p className="font-medium text-slate-900">{studentName(f)}</p>
                        </div>
                      </td>
                    )}
                    <td className="px-4 py-3 font-medium text-slate-900">{examTitle(f, examNames)}</td>
                    <td className="px-4 py-3 text-slate-600">{examSubject(f, examMap) || "-"}</td>
                    <td className="px-4 py-3 text-slate-600 whitespace-nowrap">{fmtDate(examDate)}</td>
                    <td className="px-4 py-3 text-slate-600 whitespace-nowrap">{fmtDate(submittedAt(f))}</td>
                    <td className="px-4 py-3"><StatusPill tone={statusTone(statusOf(f))}>{titleCase(statusOf(f))}</StatusPill></td>
                    <td className="px-4 py-3 text-right">
                      <RowMenu items={[{ label: "View form", icon: Eye, onClick: () => openDetail(f) }]} />
                    </td>
                  </tr>
                );
              })
            )}
          </tbody>
        </table>
      </TableCard>

      {/* View one form */}
      {detail && (
        <Modal title="Exam form" onClose={() => setDetail(null)} maxWidth="max-w-lg">
          {detailLoading ? (
            <p className="text-sm text-slate-500">Loading...</p>
          ) : (
            <dl className="grid grid-cols-1 sm:grid-cols-2 gap-x-6 gap-y-4 text-sm">
              {[
                ["Student", studentName(detail)],
                ["Exam", examTitle(detail, examNames)],
                ["Subject", examSubject(detail, examMap) || "-"],
                ["Submitted", fmtDate(submittedAt(detail))],
                ["Status", titleCase(statusOf(detail))],
                ["Form no.", detail.form_no || detail.formNo || getId(detail)],
              ].map(([k, v]) => (
                <div key={k}>
                  <dt className="text-xs uppercase tracking-wide text-slate-500">{k}</dt>
                  <dd className="mt-0.5 font-medium text-slate-900 break-words">{v}</dd>
                </div>
              ))}
            </dl>
          )}
          <div className="flex justify-end pt-5">
            <button onClick={() => setDetail(null)} className={btnOutline}>Close</button>
          </div>
        </Modal>
      )}

      {/* Student: submit a form */}
      {applying && (
        <Modal title="Apply for exam" onClose={() => setApplying(false)}>
          <form onSubmit={handleApply} className="space-y-4" noValidate>
            {applyError && <p className="text-sm text-red-600">{applyError}</p>}
            <Field label="Exam">
              <select value={applyExam} onChange={(e) => setApplyExam(e.target.value)} className={inputClass}>
                <option value="">{applyable.length ? "Select exam" : "No exam is open for forms"}</option>
                {applyable.map((e) => (
                  <option key={getId(e)} value={getId(e)}>
                    {e.title || e.name}{e.subject ? ` - ${e.subject}` : ""}{e.exam_date ? ` (${fmtDate(e.exam_date)})` : ""}
                  </option>
                ))}
              </select>
              <p className="text-xs text-slate-500 mt-1">Only exams whose form window is open are listed.</p>
            </Field>
            <div className="flex justify-end gap-3 pt-2">
              <button type="button" onClick={() => setApplying(false)} className={btnOutline}>Cancel</button>
              <button type="submit" disabled={saving || !applyable.length} className={btnPrimary}>
                <FilePlus2 size={16} /> {saving ? "Submitting..." : "Submit form"}
              </button>
            </div>
          </form>
        </Modal>
      )}
    </div>
  );
};

export default ManageExamForms;
