import api from "../../services/api";

const listOf = (data) => {
  const payload = data?.data ?? data;
  if (Array.isArray(payload)) return payload;
  for (const k of ["exam_forms", "examForms", "forms", "items", "rows", "results"]) if (Array.isArray(payload?.[k])) return payload[k];
  return [];
};

// GET /exam-forms   (staff: all forms)   |   GET /student/exam-forms   (student: own forms)
export const getExamForms = async ({ student = false, ...params } = {}) => {
  const clean = Object.fromEntries(Object.entries(params).filter(([, v]) => v !== "" && v != null));
  const { data } = await api.get(student ? "/student/exam-forms" : "/exam-forms", { params: clean });
  return listOf(data);
};

// GET /exam-forms/:id
export const getExamFormById = async (id) => {
  const { data } = await api.get(`/exam-forms/${id}`);
  const payload = data?.data ?? data;
  return payload?.exam_form ?? payload?.examForm ?? payload?.form ?? payload;
};

// POST /student/exam-forms   { exam_id }
export const submitExamForm = async (examId) => {
  const { data } = await api.post("/student/exam-forms", { exam_id: examId });
  return data?.data ?? data;
};
